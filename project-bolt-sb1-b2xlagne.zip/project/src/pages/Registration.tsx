import { Send, Crown, CheckCircle2, Shield } from 'lucide-react';

export default function Registration() {
  const openTelegram = () => {
    window.open('https://t.me/Divya_874999', '_blank');
  };

  const benefits = [
    'Exclusive access to premium club community',
    'Connect with elite lifestyle enthusiasts',
    'Private and secure networking platform',
    'Verified member profile',
    'Lifetime membership benefits',
    'Priority support and assistance',
  ];

  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/20 via-black to-black" />
        <div className="absolute top-1/4 left-1/2 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl" />

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Crown className="w-16 h-16 text-yellow-500 mx-auto mb-6 animate-pulse" />
            <h1 className="text-5xl font-bold text-white mb-6">Join LP Club</h1>
            <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-yellow-600 mx-auto mb-8" />
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Begin your journey to an exclusive luxury lifestyle experience
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <div className="bg-gradient-to-br from-yellow-500/10 to-transparent border border-yellow-500/20 rounded-2xl p-10">
              <h2 className="text-3xl font-bold text-white mb-8">Membership Details</h2>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Crown className="w-6 h-6 text-yellow-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">One-Time Fee</h3>
                    <p className="text-gray-400">
                      Single registration fee of <span className="text-yellow-500 font-bold text-2xl">₹375</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Shield className="w-6 h-6 text-yellow-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Purpose</h3>
                    <p className="text-gray-400">
                      Profile verification and administrative processing to maintain exclusivity
                    </p>
                  </div>
                </div>

                <div className="mt-8 p-6 bg-black/50 rounded-xl border border-yellow-500/30">
                  <p className="text-gray-400 text-sm">
                    No recurring fees • No membership plans • Lifetime access
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-gray-900 to-black border border-yellow-500/20 rounded-2xl p-10">
              <h2 className="text-3xl font-bold text-white mb-8">Member Benefits</h2>

              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-yellow-500 flex-shrink-0 mt-1" />
                    <p className="text-gray-400">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-yellow-500/20 via-yellow-600/20 to-yellow-500/20 border-2 border-yellow-500/50 rounded-2xl p-12 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Begin?</h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Click below to start your registration process via Telegram
            </p>

            <button
              onClick={openTelegram}
              className="group relative inline-flex items-center gap-3 px-10 py-5 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-bold rounded-xl text-lg overflow-hidden transition-all hover:shadow-2xl hover:shadow-yellow-500/50 hover:scale-105"
            >
              <span className="relative z-10">Register on Telegram</span>
              <Send className="w-6 h-6 relative z-10 group-hover:translate-x-1 transition-transform" />
            </button>

            <div className="mt-8 flex items-center justify-center gap-2 text-gray-400">
              <Shield className="w-5 h-5" />
              <p className="text-sm">Secure • Private • Exclusive</p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-500 text-sm">
              By registering, you agree to our terms of service and privacy policy
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
