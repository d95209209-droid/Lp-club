import { Link } from 'react-router-dom';
import { Crown, Users, Shield, Sparkles } from 'lucide-react';

export default function Home() {
  const features = [
    {
      icon: Crown,
      title: 'Exclusive Access',
      description: 'Join an elite community of distinguished members',
    },
    {
      icon: Users,
      title: 'Premium Networking',
      description: 'Connect with like-minded luxury lifestyle enthusiasts',
    },
    {
      icon: Shield,
      title: 'Private & Secure',
      description: 'Your privacy and exclusivity are our priority',
    },
    {
      icon: Sparkles,
      title: 'Luxury Lifestyle',
      description: 'Experience the finest in premium living',
    },
  ];

  return (
    <div className="min-h-screen bg-black">
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/20 via-black to-black" />
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-600/10 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-32">
          <div className="mb-8 inline-block">
            <Crown className="w-20 h-20 text-yellow-500 mx-auto mb-4 animate-bounce" />
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 tracking-tight">
            <span className="block">Leisure Premium Club</span>
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-600">
              Redefining Luxury
            </span>
          </h1>

          <p className="text-xl sm:text-2xl text-gray-400 mb-12 max-w-3xl mx-auto leading-relaxed">
            An exclusive private lifestyle and networking club for those who seek excellence
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/registration"
              className="group relative px-8 py-4 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-semibold rounded-lg overflow-hidden transition-all hover:shadow-2xl hover:shadow-yellow-500/50 hover:scale-105"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                Become a Member
                <Crown className="w-5 h-5" />
              </span>
            </Link>

            <Link
              to="/about"
              className="px-8 py-4 bg-white/5 text-white font-semibold rounded-lg border border-yellow-500/30 hover:bg-yellow-500/10 hover:border-yellow-500 transition-all"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      <section className="py-24 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Why LP Club?</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-yellow-600 mx-auto" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group relative p-8 bg-gradient-to-b from-yellow-500/5 to-transparent border border-yellow-500/20 rounded-xl hover:border-yellow-500/50 transition-all hover:transform hover:scale-105"
              >
                <div className="absolute inset-0 bg-gradient-to-b from-yellow-500/0 to-yellow-500/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative">
                  <feature.icon className="w-12 h-12 text-yellow-500 mb-4 group-hover:scale-110 transition-transform" />
                  <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Join?</h2>
          <p className="text-xl text-gray-400 mb-12">
            Experience luxury, exclusivity, and premium networking like never before
          </p>
          <Link
            to="/registration"
            className="inline-block px-10 py-5 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-bold rounded-lg text-lg hover:shadow-2xl hover:shadow-yellow-500/50 transition-all hover:scale-105"
          >
            Register Now
          </Link>
        </div>
      </section>
    </div>
  );
}
