import { Send, Crown, MessageCircle } from 'lucide-react';

export default function Contact() {
  const openTelegram = () => {
    window.open('https://t.me/Divya_874999', '_blank');
  };

  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/20 via-black to-black" />
        <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl animate-pulse" />

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Crown className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
            <h1 className="text-5xl font-bold text-white mb-6">Contact Us</h1>
            <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-yellow-600 mx-auto mb-8" />
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              We're here to assist you with any inquiries about LP Club membership
            </p>
          </div>

          <div className="bg-gradient-to-br from-yellow-500/10 to-transparent border-2 border-yellow-500/30 rounded-3xl p-12 md:p-16 text-center">
            <div className="mb-10">
              <div className="relative inline-block">
                <div className="absolute inset-0 bg-yellow-500/30 blur-2xl rounded-full" />
                <div className="relative w-24 h-24 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
                  <MessageCircle className="w-12 h-12 text-black" />
                </div>
              </div>

              <h2 className="text-3xl font-bold text-white mb-4">Get in Touch</h2>
              <p className="text-xl text-gray-400 mb-8">
                Connect with us on Telegram for instant assistance
              </p>
            </div>

            <div className="bg-black/50 rounded-2xl p-8 mb-10 border border-yellow-500/20">
              <p className="text-gray-400 mb-2">Contact via Telegram</p>
              <div className="flex items-center justify-center gap-3 mb-4">
                <Send className="w-6 h-6 text-yellow-500" />
                <p className="text-2xl font-bold text-yellow-500">@Divya_874999</p>
              </div>
              <p className="text-gray-500 text-sm">Fast response • Secure • Private</p>
            </div>

            <button
              onClick={openTelegram}
              className="group relative inline-flex items-center gap-3 px-12 py-6 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-bold rounded-xl text-lg overflow-hidden transition-all hover:shadow-2xl hover:shadow-yellow-500/50 hover:scale-105"
            >
              <span className="relative z-10">Contact on Telegram</span>
              <Send className="w-6 h-6 relative z-10 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </button>

            <div className="mt-12 pt-8 border-t border-yellow-500/20">
              <p className="text-gray-400 mb-6">Available for:</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-yellow-500/5 rounded-lg p-4">
                  <p className="text-white font-semibold">Membership Queries</p>
                </div>
                <div className="bg-yellow-500/5 rounded-lg p-4">
                  <p className="text-white font-semibold">Registration Support</p>
                </div>
                <div className="bg-yellow-500/5 rounded-lg p-4">
                  <p className="text-white font-semibold">General Information</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-500 text-sm">
              We typically respond within a few hours during business hours
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
