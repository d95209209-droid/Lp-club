import { Crown, Target, Eye, Award } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/20 via-black to-black" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Crown className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
            <h1 className="text-5xl font-bold text-white mb-6">About LP Club</h1>
            <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-yellow-600 mx-auto mb-8" />
            <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
              Leisure Premium Club is India's most exclusive private lifestyle and networking club,
              curated for individuals who appreciate the finer things in life.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
            <div className="bg-gradient-to-br from-yellow-500/10 to-transparent border border-yellow-500/20 rounded-2xl p-10">
              <Target className="w-14 h-14 text-yellow-500 mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">Our Mission</h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                To create an exclusive ecosystem where distinguished individuals connect, collaborate,
                and celebrate the luxury lifestyle. We bring together like-minded professionals and
                connoisseurs who value quality, privacy, and excellence in every aspect of life.
              </p>
            </div>

            <div className="bg-gradient-to-br from-yellow-500/10 to-transparent border border-yellow-500/20 rounded-2xl p-10">
              <Eye className="w-14 h-14 text-yellow-500 mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">Our Vision</h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                To be recognized as the premier luxury lifestyle club that sets the standard for
                exclusivity, sophistication, and premium experiences. We envision a community where
                every member enjoys unparalleled access to luxury and meaningful connections.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-gray-900 to-black border border-yellow-500/20 rounded-2xl p-12">
            <div className="text-center mb-12">
              <Award className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">What Makes Us Different</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-yellow-500">1</span>
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Exclusive Community</h3>
                <p className="text-gray-400">
                  Carefully curated membership ensuring quality connections with elite individuals
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-yellow-500">2</span>
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Privacy First</h3>
                <p className="text-gray-400">
                  Your privacy and security are paramount in our exclusive ecosystem
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-yellow-500">3</span>
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Premium Experience</h3>
                <p className="text-gray-400">
                  Every interaction designed to reflect luxury, elegance, and sophistication
                </p>
              </div>
            </div>
          </div>

          <div className="mt-20 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
              {['Excellence', 'Exclusivity', 'Integrity', 'Luxury'].map((value, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-b from-yellow-500/10 to-transparent border border-yellow-500/20 rounded-xl p-6 hover:border-yellow-500/50 transition-all"
                >
                  <p className="text-xl font-semibold text-yellow-500">{value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
