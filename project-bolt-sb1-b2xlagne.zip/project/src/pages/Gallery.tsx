import { Crown } from 'lucide-react';

export default function Gallery() {
  const images = [
    {
      url: 'https://images.pexels.com/photos/1567069/pexels-photo-1567069.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Luxury Lifestyle',
    },
    {
      url: 'https://images.pexels.com/photos/3186654/pexels-photo-3186654.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Premium Events',
    },
    {
      url: 'https://images.pexels.com/photos/1030737/pexels-photo-1030737.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Elite Networking',
    },
    {
      url: 'https://images.pexels.com/photos/2306203/pexels-photo-2306203.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Exclusive Venues',
    },
    {
      url: 'https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Fine Dining',
    },
    {
      url: 'https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Premium Experience',
    },
    {
      url: 'https://images.pexels.com/photos/1194713/pexels-photo-1194713.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Luxury Travel',
    },
    {
      url: 'https://images.pexels.com/photos/2869499/pexels-photo-2869499.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Sophisticated Living',
    },
    {
      url: 'https://images.pexels.com/photos/1090638/pexels-photo-1090638.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Elegant Spaces',
    },
  ];

  return (
    <div className="min-h-screen bg-black pt-20">
      <div className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/20 via-black to-black" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Crown className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
            <h1 className="text-5xl font-bold text-white mb-6">Gallery</h1>
            <div className="w-24 h-1 bg-gradient-to-r from-yellow-500 to-yellow-600 mx-auto mb-8" />
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              A glimpse into the world of luxury, elegance, and premium lifestyle
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {images.map((image, index) => (
              <div
                key={index}
                className="group relative overflow-hidden rounded-xl aspect-square cursor-pointer"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity z-10" />

                <img
                  src={image.url}
                  alt={image.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />

                <div className="absolute inset-0 z-20 flex items-end p-6">
                  <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform">
                    <h3 className="text-xl font-semibold text-white mb-2">{image.title}</h3>
                    <div className="w-12 h-1 bg-yellow-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                <div className="absolute top-4 right-4 z-20 w-10 h-10 bg-yellow-500/20 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Crown className="w-5 h-5 text-yellow-500" />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-20 text-center">
            <div className="inline-block bg-gradient-to-r from-yellow-500/10 via-yellow-600/10 to-yellow-500/10 border border-yellow-500/30 rounded-2xl p-10">
              <Crown className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-3">Experience the Lifestyle</h2>
              <p className="text-gray-400 max-w-md mx-auto">
                Join LP Club and immerse yourself in a world of luxury and exclusivity
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
