import { Send } from 'lucide-react';

export default function FloatingTelegram() {
  const openTelegram = () => {
    window.open('https://t.me/Divya_874999', '_blank');
  };

  return (
    <button
      onClick={openTelegram}
      className="fixed bottom-8 right-8 z-50 group"
      aria-label="Contact on Telegram"
    >
      <div className="relative">
        <div className="absolute inset-0 bg-yellow-500 rounded-full blur-xl opacity-50 group-hover:opacity-75 transition-opacity animate-pulse" />
        <div className="relative bg-gradient-to-br from-yellow-500 to-yellow-600 p-4 rounded-full shadow-2xl group-hover:shadow-yellow-500/50 transition-all group-hover:scale-110">
          <Send className="w-6 h-6 text-black" />
        </div>
      </div>
    </button>
  );
}
